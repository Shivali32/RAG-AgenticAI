import warnings

warnings.filterwarnings("ignore")

from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_ibm import ChatWatsonx

# Initialize Watsonx Chat Model directly
granite_llm = ChatWatsonx(
    model_id="ibm/granite-4-h-small",
    url="https://us-south.ml.cloud.ibm.com",
    project_id="skills-network",
    params={
        "max_new_tokens": 256,
        "temperature": 0.5,
    },
)

# Invoke model and print output content
response = granite_llm.invoke("What is the capital of Ontario?")
print(response.content)