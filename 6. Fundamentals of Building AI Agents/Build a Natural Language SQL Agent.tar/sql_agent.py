import argparse
import warnings

warnings.filterwarnings("ignore")

from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_ibm import ChatWatsonx

# Set up argument parser
parser = argparse.ArgumentParser()
parser.add_argument("--prompt", type=str, help="The prompt to send to the SQL agent")
args = parser.parse_args()

# Initialize Watsonx Chat Model directly
granite_llm = ChatWatsonx(
    model_id="ibm/granite-4-h-small",
    url="https://us-south.ml.cloud.ibm.com",
    project_id="skills-network",
    params={
        "max_new_tokens": 1024,
        "temperature": 0.2,
        "top_p": 0.95,
        "repetition_penalty": 1.2,
    },
)

# Database credentials & setup
mysql_username = 'root'
mysql_password = 'nVEOA1iQqBOz4cftLGdhXuTu'
mysql_host = '172.21.47.178'
mysql_port = '3306'
database_name = 'Chinook'

mysql_uri = f'mysql+mysqlconnector://{mysql_username}:{mysql_password}@{mysql_host}:{mysql_port}/{database_name}'
db = SQLDatabase.from_uri(mysql_uri)

# Create the SQL agent directly using ChatWatsonx
agent_executor = create_sql_agent(
    llm=granite_llm,
    db=db,
    verbose=True,
    handle_parsing_errors=True
)

# Execute query prompt
if args.prompt:
    agent_executor.invoke({"input": args.prompt})
else:
    print("Please provide a prompt using --prompt argument")